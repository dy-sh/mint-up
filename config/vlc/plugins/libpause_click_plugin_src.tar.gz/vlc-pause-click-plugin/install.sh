# https://github.com/nurupo/vlc-pause-click-plugin
sudo make install